    </main>

    <footer class="client-footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
            <p><a href="<?php echo app_url(''); ?>">Visit Main Website</a></p>
        </div>
    </footer>
</body>
</html>

