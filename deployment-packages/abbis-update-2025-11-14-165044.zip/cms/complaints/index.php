<?php
/**
 * CMS Complaints Front Controller
 * Provides /cms/complaints route without relying on rewrite rules.
 */
require_once __DIR__ . '/../public/complaints.php';

