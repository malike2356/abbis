<?php
/**
 * CMS Root Index - Includes public homepage
 * This file is called when accessing /cms/ directly
 */
// Change to the public directory and include the public index
require_once __DIR__ . '/public/index.php';
