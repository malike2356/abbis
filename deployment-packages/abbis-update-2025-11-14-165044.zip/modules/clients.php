<?php
/**
 * Clients Module - Redirect to Unified CRM
 * This file redirects to the unified CRM module for backward compatibility
 */
header('Location: crm.php?action=clients', true, 301);
exit;

